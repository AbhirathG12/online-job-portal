module.exports = {
    secretOrKey: "secret"
  };